class Contact {
  _id;
  Name;
  Email;
  PhoneNumber;
  Message;
  constructor() {}
}
module.exports = Contact;
