class Product {
  _id;
  Name;
  Price;
  constructor() {}
}
module.exports = Product;
